# Torre de Controle — Compras MP

App standalone (arquivo único `index.html`), extraído do repositório para virar um projeto de deploy próprio (conforme decisão de manter cada ferramenta separada do hub).

Deploy: estático, sem configuração — aponte a raiz do projeto para esta pasta na Vercel.

Depois de publicado, atualize o campo `url` do app `torre-compras` no `index.html` do **Repositório de Apps** com a URL definitiva.
